# AeroGnosis_New_GUI
AI -Enhanced UAV System for Aircraft Inspections

<!--
AI Model Integration Quickstart

Backend
1. cd backend
2. python -m venv .venv && source .venv/bin/activate
3. pip install -r requirements.txt
4. uvicorn app:app --host 0.0.0.0 --port 8000 --reload

Frontend
1. npm install
2. npm run dev

Open the CrackDetection component (AI Detection tab) in the app to upload an image and use the "Run AI Model" button.
-->
